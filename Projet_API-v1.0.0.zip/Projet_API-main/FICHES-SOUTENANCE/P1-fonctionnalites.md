# Fiche P1 : les fonctionnalités (PATCH, DELETE, filtre)

## Tes fichiers
`app/store.py`, `app/schemas.py`, `app/routes/todos.py`, `tests/test_store.py`, `tests/test_todos_project.py`

## Ce que fait le code, en clair

**Le stockage (`store.py`)** garde les tâches dans un dictionnaire Python `{id: Todo}`, en mémoire.
gunicorn traite plusieurs requêtes **en même temps** (8 *threads*, c'est-à-dire 8 fils d'exécution qui partagent
la même mémoire). D'où le **verrou** (`threading.Lock`) : un seul thread à la fois peut lire et modifier le dictionnaire.

- `update(id, title, done)` : sous le verrou, lit l'ancienne tâche, en fabrique une nouvelle avec les champs fournis
  (`dataclasses.replace`), et la range. `Todo` est `frozen` (immuable) : on ne la modifie pas, on la remplace.
  `None` veut dire « champ non envoyé, ne pas changer ».
- `delete(id)` : `pop` sous le verrou ; renvoie `True` si la tâche existait.

**Pourquoi tout sous le verrou ?** Sans lui, deux PATCH simultanés pourraient lire la même ancienne version,
et le second écraserait la modification du premier (une *race condition*, ou « situation de concurrence »).

**La validation (`schemas.py`)** : `TodoPatchSchema` (bibliothèque marshmallow) décrit ce que le client a le droit
d'envoyer :
- `title` : facultatif, mêmes règles qu'à la création (non vide, 100 caractères au plus) ;
- `done` : facultatif, booléen JSON **strict** (`StrictBoolean`) : `"true"` (chaîne) ou `1` sont refusés ;
- au moins l'un des deux, sinon 422 avec `errors.body` ;
- `unknown = EXCLUDE` : `id`, `created_at`... sont ignorés. C'est la défense contre le *mass assignment*
  (un client qui glisse des champs qu'il ne devrait pas pouvoir modifier).

**Les routes (`todos.py`)** : chaque route **lève** une exception en cas de problème (`ApiError(404, ...)` ou
`ValidationError`) ; c'est `errors.py` qui fabrique la réponse JSON. PATCH valide le corps **avant** de chercher la
tâche. DELETE renvoie `("", 204)` : 204 *No Content*, sans corps. Le filtre accepte uniquement `true`/`false`.

## Les tests
- `test_store.py` : 100 threads attendent derrière une `Barrier`, puis créent une tâche **au même instant**.
  On vérifie 100 id distincts et 100 tâches stockées. C'est un test **unitaire** : pas de HTTP, on appelle la classe.
- `test_todos_project.py` : PATCH (200, idempotence, champs ignorés, 404, `{}` 422, titre invalide 422,
  `done` non booléen 422), DELETE (204, puis 404 ; inconnue 404), filtre (`true`, `false`, valeurs invalides 422).

## Questions probables, et réponses
- **PATCH ou PUT ?** PATCH modifie **une partie** (on envoie seulement `done`) ; PUT **remplace** toute la ressource
  (titre et état obligatoires).
- **PATCH est-il idempotent ?** Ici oui : `{"done": true}` envoyé deux fois donne le même état. Il ne le serait pas
  s'il « inversait » l'état à chaque appel.
- **DELETE est idempotent, pourtant la 2e réponse est 404 ?** L'idempotence porte sur **l'état du serveur** (la tâche
  n'existe plus, une fois ou dix fois), pas sur la réponse.
- **Pourquoi 422 et pas 400 ?** 400 : la requête est illisible. 422 : le JSON est compris, mais les données violent
  les règles (titre vide, `done` pas booléen).
- **Pourquoi un verrou, alors que Python a le GIL ?** Le GIL protège une instruction, pas une **suite** d'opérations
  (lire, calculer, écrire). Entre deux, un autre thread peut passer.
- **Limite ?** Mémoire : tout est perdu au redémarrage, une seule instance possible.

## À savoir montrer
```bash
curl -s -X PATCH localhost:8081/api/v1/todos/1 -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"done": true}'
curl -s "localhost:8081/api/v1/todos?done=maybe" -H "Authorization: Bearer $TOKEN"   # 422
```
