# Intégrer le projet dans votre dépôt

Le zip contient votre dépôt complet, mis à jour. Tout le travail est dans `starter-kit-todo/flask/`.
**Vérifié** dans mon environnement : 46 tests pytest au vert, et la collection Newman passée deux fois de suite
contre l'API lancée comme en production (28 requêtes, 157 vérifications, 0 échec).
**À faire chez vous** (Docker Hub n'était pas accessible depuis mon environnement) : construire l'image,
la lancer, la pousser sur le registre, rejouer Newman contre elle.

## Ce qui a changé par rapport à votre TP 3

Votre `todos.py` contenait déjà PATCH, DELETE et le filtre, mais `store.py` n'avait ni `update()` ni `delete()`
(PATCH et DELETE auraient donc renvoyé 500). Le test `test_docs.py` était aussi rouge, car ces routes n'étaient pas
documentées. C'est corrigé.

## Qui committe quoi (pour que l'historique Git montre le travail de chacun)

Chaque personne crée sa branche, copie SES fichiers depuis le zip, committe, et ouvre une Pull Request (ou merge).
Ordre des merges : P1+P2 (dans la même PR, car ils touchent tous les deux `todos.py`), puis P3, puis P4.

| Qui | Branche | Fichiers (dans `starter-kit-todo/flask/`) |
| --- | --- | --- |
| P2 | `feat/security` | `tests/conftest.py`, `tests/test_todos.py`, `tests/test_security.py`, `.gitignore` |
| P1 | même branche, commit suivant | `app/store.py`, `app/schemas.py`, `app/routes/todos.py`, `tests/test_store.py`, `tests/test_todos_project.py` |
| P3 | `feat/docs-postman` | `docs/openapi.yaml`, `tests/test_docs_accuracy.py`, `postman/*.json` |
| P4 | `feat/docker` | `Dockerfile`, `.dockerignore`, `scripts/*`, `README.md`, `CHANGELOG.md`, `docs/schemas.md`, `docs/*.png`, `../../README.md` |

```bash
git switch -c feat/security
# copier les fichiers de P2 depuis le zip
git add tests/conftest.py tests/test_todos.py tests/test_security.py .gitignore
git commit -m "Sécurité : jeton dans les tests du TP 3, tests 401/403"
# P1 committe ensuite ses fichiers sur la même branche, puis : git push -u origin feat/security
```

## Le jour J (P4, avec tout le groupe)

```bash
cd starter-kit-todo/flask
cp .env.example .env                    # choisir les deux mots de passe
docker compose up -d --build            # dev : http://localhost:8081
docker compose run --rm tests           # 46 tests verts
scripts/newman.sh local                 # 2 exécutions sans échec
scripts/publish.sh 1.0.0                # image, vérifications, registre, push, preuve curl
scripts/run-prod.sh 1.0.0               # image seule : http://localhost:8080
scripts/newman.sh image                 # preuve que l'image est autonome
scripts/check-secrets.sh                # aucun secret dans le dépôt ni l'historique
git add postman/reports && git commit -m "Preuves d'exécution Newman"
git tag -a v1.0.0 -m "Version 1.0.0" && git push origin main v1.0.0
```

Sous Windows : lancer ces scripts depuis **Git Bash** ou **WSL**.
Faites des captures d'écran de `publish.sh` (étape 5) et des tableaux Newman pour la soutenance.

## Soutenance (10 à 15 min) : proposition

| Qui | Durée | Contenu | Support |
| --- | --- | --- | --- |
| P1 | 3 min | Architecture (routes, schémas, stockage), PATCH contre PUT, démo PATCH et filtre dans Swagger | Swagger UI |
| P2 | 3 min | Schéma de sécurisation, 401 et 403 en direct | `docs/schema-securisation.png` |
| P3 | 3 min | Swagger avec Authorize, stratégie de test, Newman en direct | Terminal |
| P4 | 3 min | Schéma de publication, démo `publish.sh`, `curl _catalog`, « passer en production », limites | `docs/schema-publication.png` |

**Avant la soutenance** : chacun lit les 4 fiches, pas seulement la sienne. Les questions peuvent viser n'importe qui.
