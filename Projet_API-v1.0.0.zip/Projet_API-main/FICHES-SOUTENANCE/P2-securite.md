# Fiche P2 : la sécurité (JWT, rôles, secrets)

## Tes fichiers
`tests/conftest.py`, `tests/test_todos.py`, `tests/test_security.py`, `.gitignore`, et les décorateurs
`@require_auth` de `app/routes/todos.py` (fichier partagé avec P1). Support : `docs/schema-securisation.png`.

## Ce que fait le code, en clair

**Le JWT** (*JSON Web Token*) est une chaîne en 3 parties `en-tête.contenu.signature`, chacune encodée en Base64.
Le contenu (`iss` l'émetteur, `upn` le nom, `groups` les rôles, `exp` l'expiration) est **lisible par tous** : il
n'est pas chiffré, il est **signé**.

**RS256** = signature avec une paire de clés RSA :
- la clé **privée** signe le jeton au login (seul le serveur l'a) ;
- la clé **publique** vérifie la signature à chaque requête.
Si quelqu'un modifie le contenu (`groups: ["admin"]` à la place de `user`), la signature ne correspond plus : 401.

**Le décorateur** `@require_auth()` (fourni, dans `security.py`) s'exécute **avant** la route :
1. pas d'en-tête `Authorization: Bearer ...` : 401 ;
2. signature fausse, émetteur faux ou jeton expiré : 401 ;
3. `@require_auth(ROLE_ADMIN)` et le rôle n'est pas admin : **403**.
Ce que j'ai fait : poser `@require_auth()` sur les 5 routes todos, et `@require_auth(ROLE_ADMIN)` sur DELETE.

**401 ou 403 ?** 401 = « je ne sais pas qui tu es » (authentification). 403 = « je sais qui tu es, mais tu n'as pas
le droit » (autorisation).

**Les tests du TP 3** : une fois les routes protégées, ils recevaient 401. Seule modification : une fixture
`autouse` (exécutée automatiquement avant chaque test du fichier) qui ajoute le jeton du compte `user` à toutes les
requêtes. Aucun statut attendu ni aucun test n'a changé. J'ai pris le compte `user` exprès : c'est le **moindre
privilège** (ces tests n'ont pas besoin d'être admin).

**Les tests de sécurité** : 401 sans jeton sur les **5** routes todos, 401 avec un jeton dont la signature est
modifiée, 403 quand `user` supprime (et la tâche existe toujours après), aucune trace Python dans une erreur.

**Les secrets** : mots de passe dans `.env`, clés dans un volume Docker. `.gitignore` exclut `.env`, `*.pem`,
`*.key`, `keys/`. `scripts/check-secrets.sh` vérifie les fichiers suivis, **tout l'historique**, puis lance
gitleaks. Les mots de passe de `conftest.py` sont fictifs : les tests génèrent leurs propres clés.

## Questions probables, et réponses
- **Peut-on lire un JWT sans la clé ?** Oui (Base64). D'où : jamais de donnée sensible dedans, et HTTPS obligatoire
  en production, car un jeton volé donne l'accès jusqu'à son expiration.
- **Pourquoi RS256 plutôt que HS256 ?** HS256 utilise une seule clé secrète qui signe ET vérifie : chaque service qui
  vérifie pourrait aussi fabriquer des jetons. En RS256, on ne distribue que la clé publique.
- **Pourquoi `algorithms=["RS256"]` en dur ?** Pour que le client ne puisse pas imposer `alg: none` (jeton non signé).
- **Pourquoi le même message pour un compte inconnu et un mauvais mot de passe ?** Pour ne pas révéler quels comptes
  existent (énumération). La comparaison est aussi en temps constant (`hmac.compare_digest`).
- **Un secret commité puis supprimé ?** Il reste dans l'historique Git. Il faut le **changer**, puis réécrire
  l'historique (`git filter-repo`).
- **Comment révoquer un jeton ?** On ne peut pas facilement : d'où la durée de vie courte (1 h).

## À savoir montrer
```bash
curl -i localhost:8081/api/v1/todos                                     # 401 + WWW-Authenticate: Bearer
curl -i -X DELETE localhost:8081/api/v1/todos/1 -H "Authorization: Bearer $USER_TOKEN"   # 403
```
Et sur https://jwt.io, coller un jeton pour montrer que son contenu est lisible (avec un jeton de démo uniquement).
