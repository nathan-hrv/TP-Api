# Fiche P4 : image Docker, registre, README

## Tes fichiers
`Dockerfile`, `.dockerignore`, `scripts/publish.sh`, `scripts/run-prod.sh`, `scripts/newman.sh`,
`scripts/check-secrets.sh`, `README.md`, `CHANGELOG.md`, `docs/schemas.md`, `docs/schema-publication.png`

## Ce que fait le code, en clair

**Le Dockerfile multi-étapes** : un seul fichier, plusieurs `FROM ... AS nom`.
- `base` : Python slim, dépendances d'exécution, création de l'utilisateur `app` ;
- `dev` : ajoute pytest, rechargement à chaud (utilisé par docker compose) ;
- `prod` : part de `base`, copie seulement `app/` et `docs/`. Les outils de test n'y sont pas.
`docker build --target prod` ne construit que ce qui mène à `prod`.

**Non root** : `USER app`. Si l'API est piratée, l'attaquant n'est pas root dans le conteneur. En plus, le code est
copié **sans** `--chown` : il appartient à root, donc le processus `app` ne peut pas le modifier.

**Aucun secret dans l'image** : `.dockerignore` exclut `.env` et `*.pem` du *contexte de build* (ce que Docker
envoie au moteur de construction). `publish.sh` vérifie qu'il n'y a ni `.env` ni `.pem` dans `/app`.
Les secrets arrivent **à l'exécution** : `--env-file .env` (mots de passe) et `-v todo-flask_jwt-keys:/keys:ro`
(clés, montées en lecture seule).

**Pourquoi un seul worker gunicorn ?** Stockage en mémoire : deux processus auraient deux listes différentes.

**HEALTHCHECK** : Docker appelle `/health` toutes les 30 s et marque le conteneur `unhealthy` s'il ne répond plus
(visible dans `docker ps`).

**Le registre** `registry:2` est un serveur d'images Docker, et c'est lui-même une **API REST** :
`GET /v2/_catalog` liste les images, `GET /v2/todo-api/tags/list` liste les versions.
`docker tag` donne à l'image un nom qui commence par l'adresse du registre ; `docker push` l'y envoie.

**Versionnage** : image `1.0.0` (et `latest`), tag Git `v1.0.0`. `latest` bouge à chaque version ; `1.0.0` désigne
toujours exactement la même image : c'est ce qu'on déploie et ce qu'on peut restaurer.

**Les scripts** :
- `publish.sh` : build, vérifications (non root, pas de secret, pas de pytest), registre, tag, push, `curl` de preuve ;
- `run-prod.sh` : lance l'image **hors** docker-compose sur le port 8080, avec `--cap-drop ALL` (aucun privilège
  Linux spécial) et `no-new-privileges` ;
- `newman.sh image` : rejoue la collection contre l'image. Si elle passe, l'image fonctionne seule.

## Questions probables, et réponses
- **Pourquoi multi-étapes ?** Image plus petite et surface d'attaque réduite : ce qui sert à construire ou tester ne
  part pas en production.
- **Différence entre `.gitignore` et `.dockerignore` ?** Le premier protège le dépôt, le second l'image. Il faut les
  deux : un `.env` peut ne pas être commité mais finir quand même dans l'image.
- **Pourquoi `127.0.0.1:8080:8080` et pas `8080:8080` ?** Sans l'adresse, le port est ouvert sur toutes les cartes
  réseau du poste, donc accessible par les autres machines du réseau.
- **Pourquoi rejouer Newman contre l'image ?** Le compose de dev monte le code depuis le poste : ça ne prouve rien
  sur l'image. Newman contre l'image prouve qu'elle contient tout ce qu'il faut.
- **Passer en production ?** (section 10 du README) HTTPS via un reverse proxy, coffre à secrets et rotation des clés,
  vraie base de données, vrais comptes (OIDC), limitation de débit, supervision, CI/CD avec scan de l'image,
  registre privé authentifié.
- **Ce qui est perfectible ?** Stockage en mémoire, pas de pagination, pas de quota de login, une seule instance.

## À savoir montrer
```bash
scripts/publish.sh 1.0.0
docker ps                       # colonne STATUS : (healthy)
curl -s http://localhost:5000/v2/_catalog
scripts/run-prod.sh 1.0.0 && scripts/newman.sh image
```
