# Fiche P3 : documentation Swagger et tests Postman

## Tes fichiers
`docs/openapi.yaml`, `tests/test_docs_accuracy.py`, `postman/todo-api.postman_collection.json`,
`postman/todo-local.postman_environment.json`, `postman/todo-image.postman_environment.json`

## Ce que fait le code, en clair

**OpenAPI** est un format standard (ici en YAML) qui décrit une API : routes, paramètres, corps, réponses, sécurité.
**Swagger UI** (`/api/docs`) le transforme en page web interactive. Dans ce kit Flask, l'approche est
« **contrat d'abord** » : le fichier `docs/openapi.yaml` est écrit à la main et servi tel quel par `/api/openapi.yaml`.
L'export demandé dans `docs/` est donc ce fichier même.

Ce que contient le contrat :
- pour chaque route : un résumé (`summary`) et **toutes** ses réponses avec une description ;
- les réponses communes factorisées dans `components/responses` (`Unauthorized`, `Forbidden`, `NotFound`...) :
  écrites une fois, réutilisées par `$ref` ;
- `securitySchemes.bearerAuth` : c'est ce qui fait apparaître le bouton **Authorize** ; chaque route protégée porte
  `security: [{ bearerAuth: [] }]`, les routes publiques `security: []` ;
- le paramètre `done` : `enum: ['true', 'false']`, avec sa description.

**« Ne rien affirmer de faux »** : deux tests le vérifient automatiquement. `test_docs.py` (fourni) : toute route du
code est documentée. `test_docs_accuracy.py` (ajouté) : une route documentée comme protégée renvoie bien 401 sans
jeton, et une route publique ne le renvoie pas ; chaque réponse a une description.

**La collection Postman** (28 requêtes, 3 dossiers) :
1. *Authentification* : login admin et login user ; les jetons sont rangés dans des **variables de collection**
   (`admin_token`, `user_token`) et réutilisés par les requêtes suivantes.
2. *Scénario rejouable* : créer, lire, PATCH, PATCH à nouveau (idempotence), filtrer `true` puis `false`, lister,
   supprimer (admin), relire (404), supprimer encore (404).
3. *Cas d'erreur* : 401 (sans jeton, jeton invalide), 403 (user supprime), 404 (lire, modifier, supprimer une tâche
   inconnue), 422 (titre vide, titre trop long, PATCH vide, `done` non booléen, filtre invalide), puis nettoyage.

Tests : chaque requête vérifie son statut et sa structure ; un script **au niveau de la collection** vérifie pour
toutes les requêtes le temps de réponse, le `Content-Type` JSON et l'absence de trace. **20 validations JSON Schema**
(un JSON Schema décrit la forme attendue d'une réponse : champs obligatoires, types).

**Rejouable** : le scénario crée ses propres tâches et les supprime ; il ne dépend d'aucune donnée existante.
La dernière requête efface les jetons des variables : un export de la collection ne contient aucun jeton.

**Sans secret** : les mots de passe sont vides dans les environnements (type `secret`). On les passe à Newman avec
`--env-var`, ou dans Postman en « valeur courante », qui n'est jamais exportée.

**Newman** est le moteur en ligne de commande de Postman. `scripts/newman.sh local|image` lance la collection deux
fois de suite et écrit des rapports JUnit dans `postman/reports/`.

## Questions probables, et réponses
- **Pourquoi deux jeux de tests (pytest et Postman) ?** pytest teste le code de l'intérieur, vite, à chaque
  modification. Newman teste l'API **déployée**, de l'extérieur, comme un vrai client, y compris l'image Docker.
- **Pourquoi lancer la collection deux fois ?** Pour prouver qu'elle ne laisse pas de données derrière elle et ne
  dépend pas d'un état initial.
- **Différence entre variable d'environnement et variable de collection ?** L'environnement change selon la cible
  (8081 ou 8080) ; la collection garde ce que les requêtes se passent entre elles (jetons, id).
- **Que vérifie un JSON Schema que `status 200` ne vérifie pas ?** Que la réponse a la bonne forme : un client qui
  attend `data.id` entier ne cassera pas.

## À savoir montrer
Swagger UI : `POST /auth/login`, copier le jeton, **Authorize**, puis `DELETE` avec le compte user (403).
Terminal : `scripts/newman.sh local` et ses deux tableaux à 0 échec.
