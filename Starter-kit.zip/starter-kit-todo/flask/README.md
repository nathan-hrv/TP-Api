# Starter kit Todo (Flask) : API de gestion de tâches

Squelette du TP 3 (chapitre 3, version 2) : une API REST de tâches, **sans base de données** (stockage en mémoire).
Flask 3, marshmallow, PyJWT (RS256), gunicorn, Swagger UI. Aucun Python n'est nécessaire sur votre poste : tout s'exécute dans Docker.

## Démarrer

```bash
cp .env.example .env
# Renseigner APP_ADMIN_PASSWORD et APP_USER_PASSWORD (mots de passe de votre choix)

docker compose up -d --build
docker compose logs -f api        # attendre "Listening at: http://0.0.0.0:8080"

curl -s http://localhost:8080/api/v1/health
```

| URL | Rôle |
| --- | --- |
| `http://localhost:8080/api/v1/health` | Route publique (exemple fourni) |
| `http://localhost:8080/api/docs` | Documentation interactive Swagger UI (chargée depuis un CDN : accès Internet requis) |
| `http://localhost:8080/api/openapi.yaml` | Contrat OpenAPI brut |

L'API tourne avec rechargement automatique : toute modification d'un fichier Python est prise en compte.

## Ce que fournit le kit

| Élément | Fichier |
| --- | --- |
| Modèle `Todo` (id entier, title, done, created_at) | `app/models.py` |
| Route publique d'exemple : `GET /health` | `app/routes/health.py` |
| Route protégée d'exemple : `GET /me` (jeton JWT exigé) | `app/routes/me.py` |
| Obtention d'un jeton : `POST /auth/login` | `app/routes/auth.py`, `app/security.py` |
| Émission et vérification des JWT (RS256), décorateur `@require_auth` | `app/security.py` |
| Gestion centralisée des erreurs (404, 422, 401, 500...) | `app/errors.py` |
| Contrat OpenAPI (déjà écrit, routes todos comprises) et Swagger UI | `docs/openapi.yaml`, `app/routes/docs.py` |
| Tests du socle (verts) | `tests/test_health.py`, `tests/test_auth.py`, `tests/test_docs.py` |
| Tests du TP 3 (rouges au départ) | `tests/test_todos.py` |
| Collection Postman et environnement | `postman/` |

## Ce que vous écrivez (TP 3)

| Étape | Fichier |
| --- | --- |
| Le stockage en mémoire | `app/store.py` (squelette à compléter) |
| Le schéma d'entrée validé | `app/schemas.py` (`TodoInputSchema`, à ajouter) |
| Les trois routes | `app/routes/todos.py` (squelette à compléter) |

Ne modifiez pas `tests/test_todos.py` : c'est le contrat.

## Commandes utiles

```bash
docker compose run --rm tests                              # tous les tests
docker compose run --rm tests pytest tests/test_todos.py   # le TP 3 seulement
docker compose exec api flask --app app routes             # la liste des routes
docker compose logs -f api                                 # journaux
docker compose restart api                                 # redémarrage (les tâches en mémoire sont perdues)
```

## Obtenir un jeton à la main

```bash
curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"<APP_ADMIN_PASSWORD>"}'
curl -s http://localhost:8080/api/v1/me -H "Authorization: Bearer <jeton>"
```

Les comptes sont `admin` (rôle `admin`) et `user` (rôle `user`).

## Pourquoi un seul processus gunicorn ?

Les tâches vivent dans la mémoire du processus. Avec plusieurs processus (`--workers 4`), chacun aurait **sa propre liste** : une tâche créée sur l'un serait introuvable sur l'autre. Le kit lance donc un seul processus et plusieurs *threads*, qui partagent la mémoire.
