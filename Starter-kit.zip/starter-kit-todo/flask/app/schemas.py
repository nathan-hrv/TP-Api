"""Schémas marshmallow : validation des entrées (load).

Règle : une entrée n'est jamais utilisée sans passer par un schéma. Un schéma décrit EXACTEMENT ce que le client
a le droit d'envoyer ; avec unknown = EXCLUDE, tout autre champ est ignoré (défense contre le mass assignment).
"""

from marshmallow import EXCLUDE, Schema, fields, validate


class LoginSchema(Schema):
    """Exemple fourni de schéma d'entrée."""

    class Meta:
        unknown = EXCLUDE

    username = fields.String(required=True, validate=validate.Length(min=1, max=50))
    password = fields.String(required=True, validate=validate.Length(min=1, max=255))


# TP 3, étape 4 : écrire ici TodoInputSchema (le corps de POST /todos).
#   - title : obligatoire, 100 caractères au plus, ni vide ni fait uniquement d'espaces ;
#   - unknown = EXCLUDE.
