"""Stockage des tâches EN MÉMOIRE : aucune base de données.

Conséquences à comprendre (voir le cours, section 3.3) :
 - tout est perdu quand l'application s'arrête ;
 - une seule instance de l'API peut tourner (deux instances auraient chacune leurs données). C'est pour cela que
   gunicorn est lancé avec UN SEUL processus : plusieurs processus auraient chacun leur mémoire ;
 - plusieurs requêtes arrivent EN MÊME TEMPS (gunicorn utilise plusieurs threads) : les modifications de
   l'état partagé doivent être protégées.

TP 3, étape 3 : compléter la classe. Tant qu'elle n'est pas écrite, l'API répond 500 sur les routes todos.
"""

from .models import Todo


class TodoStore:
    def __init__(self) -> None:
        # TP 3, étape 3 : déclarer ici
        #   - le dictionnaire qui contient les tâches (clé : identifiant) ;
        #   - le compteur qui attribue les identifiants ;
        #   - le verrou (threading.Lock) qui protège les deux.
        pass

    def create(self, title: str) -> Todo:
        """Crée une tâche (id attribué par le serveur, done à False, created_at à l'instant présent, en UTC)."""
        raise NotImplementedError("À écrire (TP 3, étape 3)")

    def find_all(self) -> list[Todo]:
        """Toutes les tâches, dans l'ordre de leur identifiant."""
        raise NotImplementedError("À écrire (TP 3, étape 3)")

    def find_by_id(self, todo_id: int) -> Todo | None:
        """Une tâche, ou None si l'identifiant est inconnu."""
        raise NotImplementedError("À écrire (TP 3, étape 3)")


# Instance unique, partagée par toute l'application (équivalent d'un @ApplicationScoped)
store = TodoStore()
