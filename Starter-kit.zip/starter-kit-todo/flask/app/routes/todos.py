"""Ressource "todos".

TP 3, étape 4 : écrire les trois routes (voir le cours, section 3.3).
  POST /api/v1/todos        créer une tâche      (201 + Location, 422 si le titre est invalide)
  GET  /api/v1/todos        lister les tâches    (200)
  GET  /api/v1/todos/<id>   lire une tâche       (200, 404 si inconnue)

Les erreurs (404, 422...) sont mises en forme par app/errors.py : il suffit de lever une ApiError
ou de laisser la validation (marshmallow) échouer.
"""

from flask import Blueprint

bp = Blueprint("todos", __name__, url_prefix="/api/v1")
